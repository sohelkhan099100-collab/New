package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class OrbView(context: Context) : View(context) {
    private val pts = ArrayList<FloatArray>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var angle = 0f
    var busy = false

    init {
        val n = 90
        val ga = Math.PI * (3 - sqrt(5.0))
        for (i in 0 until n) {
            val y = 1f - 2f * i / (n - 1)
            val r = sqrt(1f - y * y)
            val t = ga * i
            pts.add(floatArrayOf((cos(t) * r).toFloat(), y, (sin(t) * r).toFloat()))
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2
        val rad = minOf(w, h) * 0.40f
        angle += if (busy) 0.035f else 0.012f
        val ca = cos(angle)
        val sa = sin(angle)

        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, rad * 1.5f,
            intArrayOf(0x6600A8FF, 0x0000A8FF), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, rad * 1.5f, paint)
        paint.shader = null

        val px = FloatArray(pts.size)
        val py = FloatArray(pts.size)
        val pz = FloatArray(pts.size)
        for (i in pts.indices) {
            val p = pts[i]
            val x = p[0] * ca + p[2] * sa
            val z = -p[0] * sa + p[2] * ca
            px[i] = cx + x * rad
            py[i] = cy + p[1] * rad
            pz[i] = z
        }
        paint.strokeWidth = 1.5f
        for (i in pts.indices) {
            for (j in i + 1 until pts.size) {
                val dx = pts[i][0] - pts[j][0]
                val dy = pts[i][1] - pts[j][1]
                val dz = pts[i][2] - pts[j][2]
                if (dx * dx + dy * dy + dz * dz < 0.30f) {
                    val a = (((pz[i] + pz[j]) / 2 + 1f) * 55f + 20f).toInt()
                    paint.color = (a shl 24) or 0x0000B4FF
                    canvas.drawLine(px[i], py[i], px[j], py[j], paint)
                }
            }
        }
        for (i in pts.indices) {
            val a = ((pz[i] + 1f) * 100f + 55f).toInt()
            paint.color = (a shl 24) or 0x0000E5FF
            canvas.drawCircle(px[i], py[i], 3f + (pz[i] + 1f) * 2f, paint)
        }
        postInvalidateOnAnimation()
    }
}
