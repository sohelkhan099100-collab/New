package com.jarvis.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var reply: TextView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val history = ArrayList<Pair<String, String>>()
    private var modelList: List<String>? = null
    private var goodModel: String? = null
    private val BASE = "https://generativelanguage.googleapis.com/v1beta/"
    private val CYAN = Color.parseColor("#00E5FF")
    private val BLUE = Color.parseColor("#2979FF")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(dp(16), dp(24), dp(16), dp(12))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "J.A.R.V.I.S  •  ONLINE v4"
        title.setTextColor(CYAN)
        title.textSize = 17f
        title.typeface = Typeface.MONOSPACE
        title.letterSpacing = 0.15f
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = TextView(this)
        gear.text = "⚙"
        gear.setTextColor(CYAN)
        gear.textSize = 28f
        gear.setPadding(dp(12), 0, dp(4), 0)
        gear.setOnClickListener { showSettings() }
        top.addView(gear)
        root.addView(top)

        orb = OrbView(this)
        root.addView(orb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.1f))

        status = TextView(this)
        status.text = "READY"
        status.setTextColor(BLUE)
        status.typeface = Typeface.MONOSPACE
        status.gravity = Gravity.CENTER
        root.addView(status)

        val scroll = ScrollView(this)
        reply = TextView(this)
        reply.setTextColor(Color.WHITE)
        reply.textSize = 17f
        reply.setTextIsSelectable(true)
        reply.text = "नमस्ते! मैं जार्विस हूँ। नीचे लिखिए या माइक दबाइए।"
        scroll.addView(reply)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.3f))

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "यहाँ लिखिए..."
        input.setHintTextColor(Color.parseColor("#667788"))
        input.setTextColor(Color.WHITE)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.maxLines = 3
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#06101C"))
        bg.setStroke(dp(2), BLUE)
        bg.cornerRadius = dp(28).toFloat()
        input.background = bg
        input.setPadding(dp(18), dp(12), dp(18), dp(12))
        bottom.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(circleButton("➤") { send(input.text.toString()) })
        bottom.addView(circleButton("🎤") { startListening() })
        root.addView(bottom)

        setContentView(root)

        if (getKey().isEmpty()) showSettings()
    }

    private fun circleButton(label: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.textSize = 22f
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#0A3A7A"))
        bg.setStroke(dp(2), CYAN)
        b.background = bg
        val lp = LinearLayout.LayoutParams(dp(54), dp(54))
        lp.leftMargin = dp(8)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) {
            val r = tts?.setLanguage(Locale("hi", "IN"))
            ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun getKey(): String =
        getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "")?.trim() ?: ""

    private fun showSettings() {
        val et = EditText(this)
        et.hint = "Gemini API key यहाँ paste कीजिए"
        et.setText(getKey())
        et.setSingleLine(true)
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                getSharedPreferences("jarvis", MODE_PRIVATE).edit()
                    .putString("key", et.text.toString().trim()).apply()
                modelList = null
                goodModel = null
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startListening() {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए...")
            @Suppress("DEPRECATION")
            startActivityForResult(i, 77)
        } catch (e: Exception) {
            Toast.makeText(this, "Voice input इस फ़ोन पर उपलब्ध नहीं", Toast.LENGTH_LONG).show()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) send(t)
        }
    }

    private fun send(textIn: String) {
        val text = textIn.trim()
        if (text.isEmpty()) return
        val key = getKey()
        if (key.isEmpty()) { showSettings(); return }
        input.setText("")
        status.text = "THINKING..."
        status.setTextColor(BLUE)
        reply.text = "..."
        orb.busy = true
        Thread {
            var answer: String
            var ok = true
            try {
                answer = ask(key, text)
                history.add(Pair(text, answer))
                while (history.size > 10) history.removeAt(0)
            } catch (e: Exception) {
                ok = false
                answer = "माफ़ कीजिए, जवाब नहीं मिला।\n\nError details:\n" + (e.message ?: "unknown")
            }
            runOnUiThread {
                orb.busy = false
                reply.text = answer
                status.text = if (ok) "READY" else "ERROR"
                if (ok && ttsReady) {
                    tts?.speak(answer.replace("*", "").replace("#", ""), TextToSpeech.QUEUE_FLUSH, null, "j")
                }
            }
        }.start()
    }

    private fun http(method: String, url: String, key: String, body: String?): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("x-goog-api-key", key)
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, s)
    }

    // Asks Google which models this key can really use right now, newest flash first.
    private fun models(key: String): List<String> {
        modelList?.let { return it }
        val found = ArrayList<String>()
        try {
            val (code, body) = http("GET", BASE + "models?pageSize=200", key, null)
            if (code == 200) {
                val arr = JSONObject(body).optJSONArray("models") ?: JSONArray()
                val rx = Regex("gemini-(\\d+(?:\\.\\d+)?)")
                val bad = listOf("image", "tts", "live", "audio", "embedding", "robotics", "computer", "thinking", "exp", "customtools")
                val cands = ArrayList<Triple<String, Double, Boolean>>()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    val name = m.optString("name")
                    val methods = m.optJSONArray("supportedGenerationMethods")
                    var gen = false
                    if (methods != null) for (k in 0 until methods.length())
                        if (methods.getString(k) == "generateContent") gen = true
                    if (!gen || !name.contains("flash") || bad.any { name.contains(it) }) continue
                    val v = rx.find(name)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
                    cands.add(Triple(name, v, name.contains("lite")))
                }
                cands.sortWith(compareBy({ -it.second }, { it.third }, { it.first }))
                for (c in cands) found.add(c.first)
            }
        } catch (e: Exception) { }
        for (f in listOf("models/gemini-3.8-flash", "models/gemini-flash-latest")) if (!found.contains(f)) found.add(f)
        modelList = found
        return found
    }

    private fun ask(key: String, text: String): String {
        val contents = JSONArray()
        for ((u, m) in history) {
            contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", u))))
            contents.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", m))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                "तुम J.A.R.V.I.S. हो, एक निजी AI सहायक। उपयोगकर्ता जिस भाषा में बोले (मुख्यतः हिंदी) उसी में छोटा, साफ़ और मददगार जवाब दो। मार्कडाउन के तारे या हैश मत लगाओ।")))))
            .put("contents", contents)
            .toString()

        val errors = ArrayList<String>()
        val order = ArrayList<String>()
        goodModel?.let { order.add(it) }
        for (m in models(key)) if (!order.contains(m)) order.add(m)

        for (model in order.take(5)) {
            for (attempt in 1..2) {
                try {
                    val (code, resp) = http("POST", BASE + model + ":generateContent", key, body)
                    if (code == 200) {
                        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts")
                        val sb = StringBuilder()
                        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                        if (sb.isNotBlank()) { goodModel = model; return sb.toString().trim() }
                        errors.add(model.removePrefix("models/") + ": खाली जवाब")
                        break
                    }
                    val msg = try { JSONObject(resp).getJSONObject("error").optString("message") } catch (e: Exception) { resp }
                    errors.add(model.removePrefix("models/") + " [" + code + "]: " + msg.take(110))
                    if (code == 503 || code == 429 || code == 500) { Thread.sleep(1500); continue }
                    if (code == 400 || code == 401 || code == 403) {
                        if (msg.contains("API key", true)) throw RuntimeException("API key सही नहीं है। ⚙ Settings में दोबारा paste कीजिए।\n" + msg.take(110))
                    }
                    break
                } catch (e: RuntimeException) {
                    if (e.message?.startsWith("API key") == true) throw e
                    errors.add(model.removePrefix("models/") + ": " + (e.message ?: "error").take(80))
                    break
                } catch (e: Exception) {
                    errors.add(model.removePrefix("models/") + ": " + (e.message ?: "network").take(80))
                    break
                }
            }
        }
        modelList = null
        goodModel = null
        throw RuntimeException(errors.joinToString("\n"))
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
