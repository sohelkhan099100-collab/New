package com.jarvis.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** The glowing particle sphere: the face of JARVIS. */
public class SphereView extends View {

    public static final int IDLE = 0, LISTENING = 1, THINKING = 2, SPEAKING = 3;

    private static final int N = 240;
    private final float[] px = new float[N], py = new float[N], pz = new float[N];
    private final float[] sx = new float[N], sy = new float[N], sd = new float[N];
    private final int[] pa = new int[2000], pb = new int[2000];
    private int pairCount = 0;

    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int state = IDLE;
    private float level = 0f, smooth = 0f;
    private float angle = 0f;
    private long last = 0;
    private float time = 0f;
    private RadialGradient gradient;
    private final float density;

    public SphereView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        double golden = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < N; i++) {
            float y = 1f - 2f * (i + 0.5f) / N;
            float r = (float) Math.sqrt(1 - y * y);
            double th = golden * i;
            px[i] = (float) Math.cos(th) * r;
            py[i] = y;
            pz[i] = (float) Math.sin(th) * r;
        }
        for (int i = 0; i < N && pairCount < pa.length; i++) {
            for (int j = i + 1; j < N && pairCount < pa.length; j++) {
                float dx = px[i] - px[j], dy = py[i] - py[j], dz = pz[i] - pz[j];
                if (dx * dx + dy * dy + dz * dz < 0.09f) {
                    pa[pairCount] = i;
                    pb[pairCount] = j;
                    pairCount++;
                }
            }
        }
        line.setStrokeWidth(density * 0.6f);
    }

    public void setState(int s) {
        state = s;
    }

    public void setLevel(float l) {
        level = Math.max(0f, Math.min(1f, l));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float rad = Math.min(w, h) * 0.55f;
        gradient = new RadialGradient(w / 2f, h / 2f, rad,
                new int[]{Color.argb(110, 0, 140, 255), Color.argb(40, 0, 229, 255), Color.TRANSPARENT},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        glow.setShader(gradient);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        time += dt;

        float speed;
        float eff;
        switch (state) {
            case LISTENING:
                speed = 0.45f;
                eff = 0.15f + level * 0.85f;
                break;
            case THINKING:
                speed = 1.4f;
                eff = 0.3f + 0.2f * (float) Math.sin(time * 5);
                break;
            case SPEAKING:
                speed = 0.55f;
                eff = 0.45f + 0.3f * (float) Math.sin(time * 8) + 0.2f * (float) Math.sin(time * 13.7f);
                break;
            default:
                speed = 0.22f;
                eff = 0.08f + 0.05f * (float) Math.sin(time * 1.5f);
        }
        smooth += (eff - smooth) * 0.2f;
        angle += speed * dt;

        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        float R = Math.min(w, h) * 0.34f * (1f + 0.10f * smooth);

        canvas.drawCircle(cx, cy, Math.min(w, h) * 0.55f, glow);

        float ca = (float) Math.cos(angle), sa = (float) Math.sin(angle);
        float tilt = 0.35f;
        float ct = (float) Math.cos(tilt), st = (float) Math.sin(tilt);

        for (int i = 0; i < N; i++) {
            float bump = 1f + 0.12f * smooth * (float) Math.sin(time * 6 + i * 0.7f);
            float x = px[i] * bump, y = py[i] * bump, z = pz[i] * bump;
            float x1 = x * ca + z * sa;
            float z1 = -x * sa + z * ca;
            float y1 = y * ct - z1 * st;
            float z2 = y * st + z1 * ct;
            float f = 2.5f / (2.5f - z2);
            sx[i] = cx + x1 * R * f;
            sy[i] = cy + y1 * R * f;
            sd[i] = (z2 + 1f) / 2f;
        }

        line.setColor(Color.rgb(0, 190, 255));
        for (int k = 0; k < pairCount; k++) {
            int i = pa[k], j = pb[k];
            float d = (sd[i] + sd[j]) / 2f;
            line.setAlpha((int) (20 + 90 * d * (0.6f + smooth)));
            canvas.drawLine(sx[i], sy[i], sx[j], sy[j], line);
        }

        for (int i = 0; i < N; i++) {
            float d = sd[i];
            float rr = density * (1.0f + 1.8f * d) * (1f + 0.3f * smooth);
            dot.setColor(d > 0.6f ? Color.rgb(160, 245, 255) : Color.rgb(0, 200, 255));
            dot.setAlpha((int) (70 + 185 * d));
            canvas.drawCircle(sx[i], sy[i], rr, dot);
        }

        postInvalidateOnAnimation();
    }
}
