package com.jarvis.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private static final int CYAN = Color.rgb(0, 229, 255);
    private static final int BLUE = Color.rgb(41, 121, 255);

    private SphereView sphere;
    private TextView topBar, reply, statusText;
    private EditText input;
    private Button micButton;

    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean listening = false;
    private boolean busy = false;

    private final JSONArray history = new JSONArray();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();
        tts = new TextToSpeech(this, this);
        if (getKey().isEmpty()) {
            reply.setText("नमस्ते! मैं JARVIS हूँ।\nपहले ऊपर ⚙ दबाइए और अपनी Gemini key डालिए।");
        } else {
            reply.setText("नमस्ते! मैं JARVIS हूँ। माइक दबाकर बोलिए या नीचे लिखिए।");
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        // top bar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(10), dp(8), dp(4));

        topBar = new TextView(this);
        topBar.setText("J.A.R.V.I.S  •  ONLINE v3");
        topBar.setTextColor(CYAN);
        topBar.setTextSize(15);
        topBar.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        topBar.setLetterSpacing(0.15f);
        bar.addView(topBar, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button settings = new Button(this);
        settings.setText("⚙");
        settings.setTextColor(CYAN);
        settings.setTextSize(20);
        settings.setBackgroundColor(Color.TRANSPARENT);
        settings.setOnClickListener(v -> showSettings());
        bar.addView(settings, new LinearLayout.LayoutParams(dp(52), dp(48)));
        root.addView(bar);

        // sphere
        sphere = new SphereView(this);
        root.addView(sphere, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.25f));

        // status
        statusText = new TextView(this);
        statusText.setTextColor(BLUE);
        statusText.setTextSize(13);
        statusText.setGravity(Gravity.CENTER);
        statusText.setTypeface(Typeface.MONOSPACE);
        statusText.setText("STANDBY");
        root.addView(statusText, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // reply
        ScrollView scroll = new ScrollView(this);
        reply = new TextView(this);
        reply.setTextColor(Color.rgb(200, 240, 255));
        reply.setTextSize(17);
        reply.setPadding(dp(20), dp(8), dp(20), dp(8));
        reply.setTextIsSelectable(true);
        scroll.addView(reply);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // input row
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(6), dp(12), dp(12));

        input = new EditText(this);
        input.setHint("यहाँ लिखिए...");
        input.setHintTextColor(Color.rgb(70, 110, 130));
        input.setTextColor(Color.WHITE);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setPadding(dp(16), dp(10), dp(16), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(8, 20, 32));
        bg.setStroke(dp(1), BLUE);
        bg.setCornerRadius(dp(24));
        input.setBackground(bg);
        input.setOnEditorActionListener((v, actionId, e) -> {
            sendFromInput();
            return true;
        });
        row.addView(input, new LinearLayout.LayoutParams(0, dp(48), 1f));

        Button send = roundButton("➤");
        send.setOnClickListener(v -> sendFromInput());
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(dp(48), dp(48));
        lp1.leftMargin = dp(8);
        row.addView(send, lp1);

        micButton = roundButton("🎤");
        micButton.setOnClickListener(v -> onMicTapped());
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(dp(56), dp(56));
        lp2.leftMargin = dp(8);
        row.addView(micButton, lp2);

        root.addView(row);
        setContentView(root);
    }

    private Button roundButton(String label) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setTextSize(18);
        bt.setTextColor(Color.WHITE);
        bt.setPadding(0, 0, 0, 0);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(Color.rgb(10, 60, 120));
        g.setStroke(dp(2), CYAN);
        bt.setBackground(g);
        return bt;
    }

    // ---------- settings ----------

    private SharedPreferences prefs() {
        return getSharedPreferences("jarvis", Context.MODE_PRIVATE);
    }

    private String getKey() {
        return prefs().getString("gemini_key", "").trim();
    }

    private void showSettings() {
        final EditText key = new EditText(this);
        key.setHint("Gemini API key यहाँ paste कीजिए");
        key.setSingleLine(true);
        key.setInputType(InputType.TYPE_CLASS_TEXT);
        key.setText(getKey());
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(10), dp(20), 0);
        box.addView(key, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Gemini key")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    prefs().edit().putString("gemini_key", key.getText().toString().trim()).apply();
                    Toast.makeText(this, "Key save हो गई", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------- chat ----------

    private void sendFromInput() {
        String t = input.getText().toString().trim();
        if (t.isEmpty()) return;
        input.setText("");
        sendText(t);
    }

    private void sendText(final String text) {
        if (busy) {
            Toast.makeText(this, "रुकिए, JARVIS सोच रहा है...", Toast.LENGTH_SHORT).show();
            return;
        }
        final String key = getKey();
        if (key.isEmpty()) {
            reply.setText("पहले ऊपर ⚙ दबाइए और Gemini key डालिए।");
            showSettings();
            return;
        }
        stopSpeaking();
        busy = true;
        sphere.setState(SphereView.THINKING);
        statusText.setText("THINKING...");
        reply.setText("आप: " + text);

        final JSONArray contents = new JSONArray();
        try {
            for (int i = 0; i < history.length(); i++) contents.put(history.get(i));
            contents.put(turn("user", text));
        } catch (Exception ignored) {
        }

        new Thread(() -> {
            String out;
            String modelUsed = "";
            boolean ok = true;
            try {
                GeminiClient.Reply r = GeminiClient.ask(key, contents);
                out = r.text;
                modelUsed = r.model;
            } catch (Exception e) {
                ok = false;
                out = "माफ़ कीजिए, जवाब नहीं मिला।\n\nError details:\n" + e.getMessage();
            }
            final String fOut = out;
            final String fModel = modelUsed;
            final boolean fOk = ok;
            runOnUiThread(() -> {
                busy = false;
                if (fOk) {
                    try {
                        history.put(turn("user", text));
                        history.put(turn("model", fOut));
                        while (history.length() > 16) history.remove(0);
                    } catch (Exception ignored) {
                    }
                    reply.setText(fOut);
                    statusText.setText("MODEL: " + fModel);
                    speak(fOut);
                } else {
                    reply.setText(fOut);
                    statusText.setText("ERROR");
                    sphere.setState(SphereView.IDLE);
                }
            });
        }).start();
    }

    private JSONObject turn(String role, String text) throws Exception {
        return new JSONObject().put("role", role).put("parts",
                new JSONArray().put(new JSONObject().put("text", text)));
    }

    // ---------- voice output ----------

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        int r = tts.setLanguage(new Locale("hi", "IN"));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(new Locale("en", "IN"));
        }
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String id) {
                runOnUiThread(() -> sphere.setState(SphereView.SPEAKING));
            }

            @Override
            public void onDone(String id) {
                runOnUiThread(() -> {
                    sphere.setState(SphereView.IDLE);
                    statusText.setText("STANDBY");
                });
            }

            @Override
            public void onError(String id) {
                runOnUiThread(() -> sphere.setState(SphereView.IDLE));
            }
        });
        ttsReady = true;
    }

    private void speak(String text) {
        if (!ttsReady) {
            sphere.setState(SphereView.IDLE);
            return;
        }
        String clean = text.replace("*", "").replace("#", "").replace("_", " ");
        if (clean.length() > 3500) clean = clean.substring(0, 3500);
        sphere.setState(SphereView.SPEAKING);
        tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }

    private void stopSpeaking() {
        if (tts != null && ttsReady) tts.stop();
    }

    // ---------- voice input ----------

    private void onMicTapped() {
        if (listening) {
            stopListening();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            return;
        }
        startListening();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == 1 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else if (code == 1) {
            Toast.makeText(this, "माइक की अनुमति नहीं मिली। आप नीचे लिखकर भी पूछ सकते हैं।",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "इस फ़ोन पर Voice recognition उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
            return;
        }
        stopSpeaking();
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle p) {
                    statusText.setText("LISTENING...");
                }

                @Override
                public void onBeginningOfSpeech() {
                }

                @Override
                public void onRmsChanged(float rms) {
                    sphere.setLevel((rms + 2f) / 12f);
                }

                @Override
                public void onBufferReceived(byte[] buffer) {
                }

                @Override
                public void onEndOfSpeech() {
                    statusText.setText("PROCESSING...");
                }

                @Override
                public void onError(int error) {
                    listening = false;
                    micButton.setText("🎤");
                    sphere.setState(SphereView.IDLE);
                    sphere.setLevel(0);
                    statusText.setText("STANDBY");
                    if (error != SpeechRecognizer.ERROR_NO_MATCH
                            && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        Toast.makeText(MainActivity.this, "Voice error code: " + error,
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, "कुछ सुनाई नहीं दिया, फिर कोशिश कीजिए।",
                                Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onResults(Bundle results) {
                    listening = false;
                    micButton.setText("🎤");
                    sphere.setLevel(0);
                    ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) {
                        sendText(list.get(0));
                    } else {
                        sphere.setState(SphereView.IDLE);
                        statusText.setText("STANDBY");
                    }
                }

                @Override
                public void onPartialResults(Bundle partial) {
                    ArrayList<String> list = partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) reply.setText("आप: " + list.get(0));
                }

                @Override
                public void onEvent(int type, Bundle params) {
                }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        listening = true;
        micButton.setText("⏹");
        sphere.setState(SphereView.LISTENING);
        recognizer.startListening(i);
    }

    private void stopListening() {
        listening = false;
        micButton.setText("🎤");
        if (recognizer != null) recognizer.cancel();
        sphere.setState(SphereView.IDLE);
        sphere.setLevel(0);
        statusText.setText("STANDBY");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (recognizer != null) recognizer.destroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }
}
