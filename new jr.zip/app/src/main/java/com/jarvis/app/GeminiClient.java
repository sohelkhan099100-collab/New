package com.jarvis.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Talks to Google Gemini. Tries several models, retries when the server is busy. */
public class GeminiClient {

    public static class Reply {
        public final String text;
        public final String model;
        Reply(String text, String model) {
            this.text = text;
            this.model = model;
        }
    }

    private static final String[] MODELS = {
            "gemini-2.5-flash",
            "gemini-2.0-flash",
            "gemini-2.5-flash-lite",
            "gemini-flash-latest"
    };

    private static final String SYSTEM =
            "You are J.A.R.V.I.S., a friendly personal AI assistant like the one in Iron Man. "
                    + "Reply in simple Hinglish (Hindi written in Roman letters mixed with easy English) by default. "
                    + "If the user writes in Hindi (Devanagari), reply in Hindi. If the user writes English, reply in English. "
                    + "Keep answers short and clear, like a spoken conversation. Do not use markdown, stars or bullet symbols. "
                    + "Never invent live data such as prices or news; say honestly when you do not know.";

    public static Reply ask(String apiKey, JSONArray contents) throws Exception {
        StringBuilder errors = new StringBuilder();
        for (String model : MODELS) {
            for (int attempt = 0; attempt < 2; attempt++) {
                int code = -1;
                try {
                    URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/"
                            + model + ":generateContent");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(40000);
                    c.setRequestMethod("POST");
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    c.setRequestProperty("x-goog-api-key", apiKey);

                    JSONObject body = new JSONObject();
                    body.put("systemInstruction", new JSONObject().put("parts",
                            new JSONArray().put(new JSONObject().put("text", SYSTEM))));
                    body.put("contents", contents);
                    body.put("generationConfig", new JSONObject()
                            .put("temperature", 0.8)
                            .put("maxOutputTokens", 1500));

                    OutputStream os = c.getOutputStream();
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                    os.close();

                    code = c.getResponseCode();
                    InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
                    String raw = readAll(is);
                    c.disconnect();

                    if (code == 200) {
                        String text = parseText(raw);
                        if (text != null && text.trim().length() > 0) {
                            return new Reply(text.trim(), model);
                        }
                        errors.append(model).append(": खाली जवाब\n");
                        break;
                    }

                    errors.append(model).append(": ").append(code).append(" ")
                            .append(parseError(raw)).append("\n");

                    if (code == 503 || code == 429 || code == 500) {
                        Thread.sleep(1500L * (attempt + 1));
                        continue; // retry same model once
                    }
                    break; // other errors: go to next model
                } catch (Exception e) {
                    errors.append(model).append(": ").append(e.getClass().getSimpleName())
                            .append(" ").append(e.getMessage()).append("\n");
                    if (attempt == 0) {
                        Thread.sleep(1000);
                        continue;
                    }
                }
            }
        }
        throw new Exception(errors.toString().trim());
    }

    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        br.close();
        return sb.toString();
    }

    private static String parseText(String raw) {
        try {
            JSONObject j = new JSONObject(raw);
            JSONArray parts = j.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length(); i++) {
                sb.append(parts.getJSONObject(i).optString("text", ""));
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private static String parseError(String raw) {
        try {
            String m = new JSONObject(raw).getJSONObject("error").optString("message", "");
            if (m.length() > 120) m = m.substring(0, 120) + "...";
            return m;
        } catch (Exception e) {
            return "";
        }
    }
}
